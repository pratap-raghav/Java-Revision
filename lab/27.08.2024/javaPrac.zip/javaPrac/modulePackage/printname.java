import mypackage.myclass;

public class printname {
    public static void main(String[] args) {
        String name = "Raghav";
        
        myclass m = new myclass();
        m.getname(name);
    }
}
