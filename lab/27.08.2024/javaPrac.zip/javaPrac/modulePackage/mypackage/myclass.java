package mypackage;

public class myclass {
    public void getname(String s) {
        System.out.println("Name: " + s);
    }
}
