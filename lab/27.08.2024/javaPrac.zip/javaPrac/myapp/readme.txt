implement inheritance, exception handling, package, and interface
