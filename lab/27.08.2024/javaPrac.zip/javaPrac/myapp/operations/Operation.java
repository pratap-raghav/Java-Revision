package myapp.operations;

public interface Operation {
    int add(int a, int b);
    int sub(int a, int b);
}
